package vgacard;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author Naufal
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField id;
    @FXML
    private TextField vgacard;
    @FXML
    private ComboBox<String> warna;
    @FXML
    private DatePicker tanggal;
    @FXML
    private TextField harga;
    private Button simpan;
    @FXML
    private TableView<vgaCard> datavga;
    @FXML
    private TableColumn<vgaCard, Integer> id1;
    @FXML
    private TableColumn<vgaCard, String> vgacard1;
    @FXML
    private TableColumn<vgaCard, String> warna1;
    @FXML
    private TableColumn<vgaCard, String> tanggal1;
    @FXML
    private TableColumn<vgaCard, String> harga1;
    @FXML
    private Button btninsert;
    @FXML
    private Button btndelete;
    @FXML
    private Button btnupdate;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource() == btninsert){
            insertRecord();
        }else if (event.getSource() == btnupdate){
            updateRecord();
        }else if(event.getSource() == btndelete){
            deleteButton();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        showBooks();
         ArrayList <String> list = new ArrayList<String>();
        list.add("Hitam");
        list.add("Hijau");
        list.add("Merah");
        list.add("Biru");
        ObservableList items = FXCollections.observableArrayList(list);
        warna.setItems(items);
        
    }    
    
    
    public Connection getConnection(){
        Connection conn;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/desktop", "root","");
            return conn;
        }catch(Exception ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }
    
    public ObservableList<vgaCard> getBooksList() {
        ObservableList<vgaCard> bookList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * FROM vga_card";
        Statement st;
        ResultSet rs;
    
        try{
            st = conn.createStatement();
            rs = st.executeQuery(query);
            vgaCard vga;
            while(rs.next()){
                vga = new vgaCard(rs.getInt("id"), rs.getString("vga_card"), rs.getString("warna"), rs.getString("tanggal_beli"),rs.getString("harga"));
                bookList.add(vga);
            }
    }catch(Exception ex){
        ex.printStackTrace();
        }
    return bookList;
    }


    private void showBooks() {
        ObservableList<vgaCard> list = getBooksList();
        
        id1.setCellValueFactory(new PropertyValueFactory<vgaCard, Integer>("id"));
        vgacard1.setCellValueFactory(new PropertyValueFactory<vgaCard, String>("vga_card"));
        warna1.setCellValueFactory(new PropertyValueFactory<vgaCard, String>("warna"));
        tanggal1.setCellValueFactory(new PropertyValueFactory<vgaCard, String>("tanggal_beli"));
        harga1.setCellValueFactory(new PropertyValueFactory<vgaCard, String>("harga"));
        
        datavga.setItems(list);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void insertRecord() {
        String query = "INSERT INTO vga_card VALUES (" + id.getText() + ",'" + vgacard.getText() + "','" + warna.getValue() + "',"
                + tanggal.getValue().toString() + "," + harga.getText() +")";
        executeQuery(query);
        showBooks();
    }

    private void updateRecord() {
        String query = "UPDATE  vga_card SET vga_card  = '" + vgacard.getText() + "', warna = '" + warna.getValue() + "', tanggal = " +
                tanggal.getValue().toString() + ", harga = " + harga.getText() + " WHERE id = " + id.getText() + "";
        executeQuery(query);
        showBooks();
   }

    private void deleteButton() {
        String query = "DELETE FROM vga_card WHERE id =" + id.getText() + "";
        executeQuery(query);
        showBooks();
    }

    private void executeQuery(String query) {
        Connection conn = getConnection();
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(query);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}
