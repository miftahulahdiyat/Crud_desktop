/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vgacard;

 

public class vgaCard {
    
    private int id;
    private String vga_card;
    private String warna;
    private String tanggal_beli;
    private String harga;
    
    public vgaCard(int id, String vga_card, String warna, String tanggal_beli, String harga){
    
    this.id = id;
    this.vga_card = vga_card;
    this.warna = warna;
    this.tanggal_beli = tanggal_beli;
    this.harga = harga;
    
    }

    public int getId() {
        return id;
    }

    public String getVga_card() {
        return vga_card;
    }

    public String getWarna() {
        return warna;
    }

    public String getTanggal_beli() {
        return tanggal_beli;
    }

    public String getHarga() {
        return harga;
    }

    
    
    
}
